class MediaItem {
  final String id;
  final String title;
  final String timestamp;
  final String hash;
  final double authenticityScore;
  final String status;
  final String source;

  MediaItem({
    required this.id,
    required this.title,
    required this.timestamp,
    required this.hash,
    required this.authenticityScore,
    required this.status,
    required this.source,
  });

  factory MediaItem.fromJson(Map<String, dynamic> json) {
    return MediaItem(
      id: json['id'],
      title: json['title'],
      timestamp: json['timestamp'],
      hash: json['hash'],
      authenticityScore: json['authenticityScore'],
      status: json['status'],
      source: json['source'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'timestamp': timestamp,
      'hash': hash,
      'authenticityScore': authenticityScore,
      'status': status,
      'source': source,
    };
  }
}

class VerificationResult {
  final bool isAuthentic;
  final double confidence;
  final String source;
  final String timestamp;
  final String blockchainHash;
  final bool manipulationDetected;

  VerificationResult({
    required this.isAuthentic,
    required this.confidence,
    required this.source,
    required this.timestamp,
    required this.blockchainHash,
    required this.manipulationDetected,
  });
}