import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16.0),
      child: Column(
        children: [
          Card(
            child: Padding(
              padding: EdgeInsets.all(20.0),
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 40,
                    backgroundColor: Colors.blue[800],
                    child: Icon(Icons.person, size: 40, color: Colors.white),
                  ),
                  SizedBox(height: 15),
                  Text(
                    'Dr. Sarah Chen',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    'Verified Journalist - The Times Network',
                    style: TextStyle(color: Colors.grey[600]),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 15),
                  Chip(
                    label: Text('Trust Score: 92.5%'),
                    backgroundColor: Colors.green[50],
                    labelStyle: TextStyle(fontWeight: FontWeight.bold, color: Colors.green),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 20),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: Icon(Icons.verified_user, color: Colors.blue),
                  title: Text('Digital Identity Verified'),
                  subtitle: Text('KYC Completed • Level 3 Verification'),
                  trailing: Icon(Icons.check_circle, color: Colors.green),
                ),
                ListTile(
                  leading: Icon(Icons.analytics, color: Colors.green),
                  title: Text('Media Verified'),
                  subtitle: Text('15 successful verifications'),
                ),
                ListTile(
                  leading: Icon(Icons.security, color: Colors.orange),
                  title: Text('Blockchain Address'),
                  subtitle: Text('0x742d35Sankalp6632...'),
                ),
                ListTile(
                  leading: Icon(Icons.workspace_premium, color: Colors.purple),
                  title: Text('Reputation Score'),
                  subtitle: Text('Top 10% of Verified Journalists'),
                ),
              ],
            ),
          ),
          SizedBox(height: 20),
          Expanded(
            child: Card(
              child: Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Sankalp Impact Statistics',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 15),
                    _buildStatItem('Misinformation Prevented', '1,247 cases'),
                    _buildStatItem('Media Verified', '5,892 items'),
                    _buildStatItem('Trust Score Accuracy', '92.5%'),
                    _buildStatItem('Active Journalists', '2,847 users'),
                    _buildStatItem('Countries Served', '48 countries'),
                    _buildStatItem('Elections Protected', '12 national elections'),
                    SizedBox(height: 20),
                    Divider(),
                    SizedBox(height: 10),
                    Text(
                      'Business Model',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 10),
                    _buildBusinessItem('API Verification', '\$0.01 per call'),
                    _buildBusinessItem('Enterprise Plan', '\$99/month'),
                    _buildBusinessItem('Govt Contracts', 'Election integrity'),
                    _buildBusinessItem('Browser Extension', 'Consumer verification'),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String title, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: TextStyle(fontSize: 16)),
          Text(value, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.blue[800])),
        ],
      ),
    );
  }

  Widget _buildBusinessItem(String service, String price) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(service, style: TextStyle(fontSize: 14)),
          Text(price, style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.green)),
        ],
      ),
    );
  }
}