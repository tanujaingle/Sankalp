import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthProvider with ChangeNotifier {
  bool _isAuthenticated = false;
  String _userName = '';
  String _userType = 'Journalist';
  double _trustScore = 92.5;

  bool get isAuthenticated => _isAuthenticated;
  String get userName => _userName;
  String get userType => _userType;
  double get trustScore => _trustScore;

  Future<void> login(String email, String password) async {
    // Simulate API call
    await Future.delayed(Duration(seconds: 1));
    
    _isAuthenticated = true;
    _userName = 'Dr. Sarah Chen';
    _userType = 'Verified Journalist';
    
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isAuthenticated', true);
    await prefs.setString('userName', _userName);
    
    notifyListeners();
  }

  Future<void> logout() async {
    _isAuthenticated = false;
    _userName = '';
    
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('isAuthenticated');
    await prefs.remove('userName');
    
    notifyListeners();
  }

  Future<void> checkAuthStatus() async {
    final prefs = await SharedPreferences.getInstance();
    _isAuthenticated = prefs.getBool('isAuthenticated') ?? false;
    _userName = prefs.getString('userName') ?? '';
    notifyListeners();
  }
}