import 'package:flutter/material.dart';

class VerifyScreen extends StatefulWidget {
  @override
  _VerifyScreenState createState() => _VerifyScreenState();
}

class _VerifyScreenState extends State<VerifyScreen> {
  final TextEditingController _mediaIdController = TextEditingController();
  bool _isVerifying = false;
  Map<String, dynamic>? _verificationResult;

  void _verifyMedia() {
    if (_mediaIdController.text.isEmpty) return;
    
    setState(() {
      _isVerifying = true;
    });
    
    // Simulate AI verification process
    Future.delayed(Duration(seconds: 2), () {
      setState(() {
        _isVerifying = false;
        _verificationResult = {
          'isAuthentic': true,
          'confidence': 92.5,
          'source': 'Verified Journalist: Dr. Sarah Chen',
          'timestamp': '2024-01-15 10:30:00 GMT',
          'blockchainHash': 'a1b2c3d4e5f6g7h8i9j0',
          'manipulationDetected': false,
        };
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16.0),
      child: Column(
        children: [
          Card(
            child: Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Text(
                    'Verify Media Authenticity',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 15),
                  TextField(
                    controller: _mediaIdController,
                    decoration: InputDecoration(
                      labelText: 'Enter Media ID or Hash',
                      border: OutlineInputBorder(),
                      suffixIcon: Icon(Icons.qr_code_scanner),
                    ),
                  ),
                  SizedBox(height: 15),
                  ElevatedButton(
                    onPressed: _isVerifying ? null : _verifyMedia,
                    child: _isVerifying 
                        ? CircularProgressIndicator(color: Colors.white)
                        : Text('Verify Authenticity'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue[800],
                      foregroundColor: Colors.white,
                      minimumSize: Size(double.infinity, 50),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 20),
          
          if (_verificationResult != null)
            Card(
              color: _verificationResult!['isAuthentic'] ? Colors.green[50] : Colors.red[50],
              child: Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          _verificationResult!['isAuthentic'] ? Icons.verified : Icons.warning,
                          color: _verificationResult!['isAuthentic'] ? Colors.green : Colors.red,
                        ),
                        SizedBox(width: 10),
                        Text(
                          _verificationResult!['isAuthentic'] 
                              ? '✅ Media Verified Authentic' 
                              : '❌ Potential Manipulation Detected',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    SizedBox(height: 15),
                    _buildVerificationDetail('Confidence Score', '${_verificationResult!['confidence']}%'),
                    _buildVerificationDetail('Source', _verificationResult!['source']),
                    _buildVerificationDetail('Timestamp', _verificationResult!['timestamp']),
                    _buildVerificationDetail('Blockchain Hash', _verificationResult!['blockchainHash']),
                    _buildVerificationDetail('AI Analysis', 'No manipulation detected'),
                  ],
                ),
              ),
            ),
          
          SizedBox(height: 20),
          Card(
            child: Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'How Sankalp Verification Works:',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  _buildStep('1. Witness Agent extracts digital fingerprints'),
                  _buildStep('2. Blockchain stores immutable hash'),
                  _buildStep('3. Context Agent analyzes source credibility'),
                  _buildStep('4. AI models detect deepfakes & manipulations'),
                  _buildStep('5. Real-time verification result in 2 seconds'),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVerificationDetail(String title, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('• ', style: TextStyle(fontWeight: FontWeight.bold)),
          Expanded(child: Text('$title: $value')),
        ],
      ),
    );
  }

  Widget _buildStep(String text) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('🔹 ', style: TextStyle(fontWeight: FontWeight.bold)),
          Expanded(child: Text(text)),
        ],
      ),
    );
  }
}