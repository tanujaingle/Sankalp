package com.example.sankalp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
