import 'package:flutter/material.dart';

class DashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Card(
            child: Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Sankalp Dashboard', 
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.blue[800])),
                  SizedBox(height: 10),
                  Text('🚀 Agentic AI System for Misinformation Prevention'),
                  SizedBox(height: 5),
                  Text('✅ Digital Birth Certificates for Media'),
                  SizedBox(height: 5),
                  Text('🔗 Blockchain-based Verification'),
                  SizedBox(height: 5),
                  Text('🤖 AI-Powered Authenticity Analysis'),
                ],
              ),
            ),
          ),
          SizedBox(height: 20),
          Text('Recent Activity', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          SizedBox(height: 10),
          Expanded(
            child: ListView(
              children: [
                ListTile(leading: Icon(Icons.verified, color: Colors.green), title: Text('Press Conference Image'), subtitle: Text('Verified - 95% Authentic')),
                ListTile(leading: Icon(Icons.verified, color: Colors.green), title: Text('Election Rally Video'), subtitle: Text('Verified - 88% Authentic')),
                ListTile(leading: Icon(Icons.pending, color: Colors.orange), title: Text('News Article'), subtitle: Text('Under Review - 75% Authentic')),
              ],
            ),
          ),
        ],
      ),
    );
  }
}