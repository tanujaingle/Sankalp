class AppConstants {
  static const String appName = 'Sankalp';
  static const String appTagline = 'Truth at Source';
  static const String appDescription = 'Decentralized AI System for Combating Misinformation';
  
  // API Endpoints (Mock for demo)
  static const String baseUrl = 'https://api.sankalp.com';
  static const String verifyEndpoint = '$baseUrl/verify';
  static const String uploadEndpoint = '$baseUrl/upload';
  static const String blockchainEndpoint = '$baseUrl/blockchain';
  
  // Agent Names
  static const String witnessAgent = 'Witness Agent';
  static const String contextAgent = 'Context Agent';
  static const String validatorAgent = 'Validator Agent';
  static const String sentinelAgent = 'Sentinel Agent';
  static const String governanceAgent = 'Governance Agent';
}

class AppColors {
  static const primaryColor = 0xFF1E88E5;
  static const secondaryColor = 0xFF42A5F5;
  static const successColor = 0xFF4CAF50;
  static const warningColor = 0xFFFF9800;
  static const errorColor = 0xFFF44336;
}