import 'package:flutter/material.dart';

class UploadScreen extends StatefulWidget {
  @override
  _UploadScreenState createState() => _UploadScreenState();
}

class _UploadScreenState extends State<UploadScreen> {
  final TextEditingController _titleController = TextEditingController();
  bool _isUploading = false;

  void _uploadMedia() {
    if (_titleController.text.isEmpty) return;
    
    setState(() {
      _isUploading = true;
    });
    
    // Simulate upload and verification process
    Future.delayed(Duration(seconds: 3), () {
      setState(() {
        _isUploading = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('✅ Media uploaded! Digital Birth Certificate generated.'),
          backgroundColor: Colors.green,
        ),
      );
      
      _titleController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16.0),
      child: Column(
        children: [
          Card(
            child: Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Icon(Icons.cloud_upload, size: 60, color: Colors.blue[800]),
                  SizedBox(height: 15),
                  Text(
                    'Upload Media for Digital Birth Certificate',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 20),
                  TextField(
                    controller: _titleController,
                    decoration: InputDecoration(
                      labelText: 'Media Title/Description',
                      border: OutlineInputBorder(),
                      hintText: 'e.g., Press Conference January 15',
                    ),
                  ),
                  SizedBox(height: 15),
                  Text(
                    'Supported formats: JPEG, PNG, MP4, MOV, PDF',
                    style: TextStyle(color: Colors.grey[600]),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton.icon(
                    onPressed: _isUploading ? null : _uploadMedia,
                    icon: _isUploading ? CircularProgressIndicator(color: Colors.white) : Icon(Icons.cloud_upload),
                    label: Text(_isUploading ? 'Creating Digital Certificate...' : 'Upload & Verify Media'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      foregroundColor: Colors.white,
                      minimumSize: Size(double.infinity, 50),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 20),
          Card(
            child: Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Sankalp Agentic AI Architecture',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 15),
                  _buildAgent('🤖 Witness Agent', 'Source Registration & Feature Extraction'),
                  _buildAgent('🧠 Context Agent', 'Intent Analysis & Credibility Scoring'),
                  _buildAgent('🔍 Validator Agent', 'Public Verification & Trust Checks'),
                  _buildAgent('🛡️ Sentinel Agent', 'Tamper Detection & Deepfake Analysis'),
                  _buildAgent('⚖️ Governance Agent', 'DAO-based Ethical Oversight'),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAgent(String name, String description) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 1,
            child: Text(name, style: TextStyle(fontWeight: FontWeight.bold)),
          ),
          Expanded(
            flex: 2,
            child: Text(description, style: TextStyle(color: Colors.grey[700])),
          ),
        ],
      ),
    );
  }
}