import 'package:flutter/foundation.dart';
import '../models/media_model.dart';

class MediaProvider with ChangeNotifier {
  List<MediaItem> _mediaItems = [
    MediaItem(
      id: '1',
      title: 'Press Conference Image',
      timestamp: '2024-01-15 10:30:00',
      hash: 'a1b2c3d4e5',
      authenticityScore: 95.0,
      status: 'Verified',
      source: 'The Times Network',
    ),
    MediaItem(
      id: '2',
      title: 'Election Rally Video',
      timestamp: '2024-01-15 14:20:00',
      hash: 'f6g7h8i9j0',
      authenticityScore: 88.5,
      status: 'Verified',
      source: 'News24',
    ),
    MediaItem(
      id: '3',
      title: 'Government Announcement',
      timestamp: '2024-01-15 16:45:00',
      hash: 'k1l2m3n4o5',
      authenticityScore: 92.0,
      status: 'Verified',
      source: 'Official Press',
    ),
  ];

  List<MediaItem> get mediaItems => _mediaItems;

  Future<void> uploadMedia(String title, String source) async {
    // Generate mock hash
    String hash = _generateHash(title);
    
    var newItem = MediaItem(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      title: title,
      timestamp: DateTime.now().toString(),
      hash: hash,
      authenticityScore: 85.0 + (DateTime.now().millisecond % 15),
      status: 'Verified',
      source: source,
    );
    
    _mediaItems.insert(0, newItem);
    notifyListeners();
  }

  Future<VerificationResult> verifyMedia(String mediaId) async {
    await Future.delayed(Duration(seconds: 2));
    
    return VerificationResult(
      isAuthentic: true,
      confidence: 92.5,
      source: 'Verified Journalist: Dr. Sarah Chen',
      timestamp: '2024-01-15 10:30:00 GMT',
      blockchainHash: 'a1b2c3d4e5f6g7h8i9j0',
      manipulationDetected: false,
    );
  }

  String _generateHash(String input) {
    // Simple hash generation for demo
    return (input.hashCode % 1000000).toString().padLeft(6, '0');
  }
}