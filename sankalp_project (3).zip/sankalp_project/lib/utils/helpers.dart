import 'package:crypto/crypto.dart';
import 'dart:convert';

class Helpers {
  static String generateBlockchainHash(String input) {
    var bytes = utf8.encode(input + DateTime.now().toString());
    var digest = sha256.convert(bytes);
    return digest.toString().substring(0, 16);
  }

  static String formatTimestamp(DateTime timestamp) {
    return '${timestamp.year}-${timestamp.month.toString().padLeft(2, '0')}-${timestamp.day.toString().padLeft(2, '0')} ${timestamp.hour.toString().padLeft(2, '0')}:${timestamp.minute.toString().padLeft(2, '0')}';
  }

  static double calculateTrustScore(int verifications, int successful) {
    if (verifications == 0) return 50.0;
    double baseScore = (successful / verifications) * 100;
    return baseScore > 100 ? 100.0 : baseScore;
  }

  static String truncateHash(String hash, {int length = 10}) {
    if (hash.length <= length) return hash;
    return '${hash.substring(0, length)}...';
  }
}